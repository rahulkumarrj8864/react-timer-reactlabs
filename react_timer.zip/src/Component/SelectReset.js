import React,{useState} from "react";

const SelectReset = () => {
    const options = [10, 20, 30, 40, 50];
    const [remainingTime, setRemainingTime] = useState("10")
    const handleChange = (e)=> {
        setRemainingTime(e.target.value)
    }
  return (
    <div style={{ display: "flex" }}>
      <select onChange={handleChange}>
        {options.map((opt) => (
          <option value={opt} key={opt} >
            {opt + " sec"}
          </option>
        ))}
      </select>
      <button onClick={() => setRemainingTime(remainingTime)}>Reset </button>
    </div>
  );
};
export default SelectReset;