import React, { useState } from 'react'
import { CountdownCircleTimer } from 'react-countdown-circle-timer'

export default function Learn() {
    // const [duration,setDuration] = useState(null)
    let initialRemainingTime = 10
    const handleClick = () => {
        // updateInterval(() => {
        // })
    //    setDuration(remainingTime)
        // alert("hel")
    }
    
  return (
    <>
<CountdownCircleTimer
    isPlaying = {true}
    duration={10}
    colors={['#004777', '#F7B801', '#A30000', '#A30000']}
    colorsTime={[7, 5, 2, 0]}
    // updateInterval = {0}
    // initialRemainingTime={20}
    // onUpdate={(remainingTime) => {
    //     console.log(remainingTime = 20)
    // }}
    // children = {props(remainingTime)}
    initialRemainingTime = {initialRemainingTime}
    // onComplete={() => {
    //   // do your stuff here
    //   return { shouldRepeat: true, delay: 1.5,newInitialRemainingTime:20 } // repeat animation in 1.5 seconds
    // }}
  >
    {({ remainingTime}) => remainingTime == 0 ? "Too Late" :remainingTime}
    {/* {elapsedTime} */}
  </CountdownCircleTimer>
  <button onClick={handleClick}>Reset</button>
    </>
  )
}
